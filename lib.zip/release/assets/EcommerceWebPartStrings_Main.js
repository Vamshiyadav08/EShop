import * as React from 'react';
import { HashRouter as Router, Route, Routes, } from 'react-router-dom';
import Home from '../Pages/HomePage/Home';
import styles from '../components/Main.module.scss';
// import { Link } from 'react-router-dom';
var Main = function () {
    return (React.createElement("div", { className: styles.Main },
        React.createElement(Router, null,
            React.createElement("div", null,
                React.createElement(Home, null),
                React.createElement(React.Fragment, null,
                    React.createElement(Routes, null,
                        React.createElement(Route, { path: '/main', Component: Home })))))));
};
export default Main;
//# sourceMappingURL=Main.js.map