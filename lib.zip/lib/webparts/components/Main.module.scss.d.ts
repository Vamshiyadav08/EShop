declare const styles: {
    Main: string;
};
export default styles;
//# sourceMappingURL=Main.module.scss.d.ts.map