declare const styles: {};
export default styles;
//# sourceMappingURL=footer.scss.d.ts.map