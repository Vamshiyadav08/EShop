declare const styles: {};
export default styles;
//# sourceMappingURL=Main.scss.d.ts.map