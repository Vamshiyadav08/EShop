declare const styles: {};
export default styles;
//# sourceMappingURL=header.scss.d.ts.map