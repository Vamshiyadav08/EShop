declare const styles: {
    header: string;
    navHeader: string;
    navLogo: string;
    searchbar: string;
    navActions: string;
    navActionItems: string;
    navCatagories: string;
    catagoryItems: string;
    catagoryImg: string;
    catagoryText: string;
};
export default styles;
//# sourceMappingURL=header.module.scss.d.ts.map