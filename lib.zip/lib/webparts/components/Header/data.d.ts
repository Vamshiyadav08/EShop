export declare const categories: {
    imageSrc: any;
    altText: string;
    categoryName: string;
}[];
//# sourceMappingURL=data.d.ts.map