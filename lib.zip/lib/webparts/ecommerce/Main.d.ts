import * as React from 'react';
import type { IEcommerceProps } from './IEcommerceProps';
declare const Main: React.FC<IEcommerceProps>;
export default Main;
//# sourceMappingURL=Main.d.ts.map