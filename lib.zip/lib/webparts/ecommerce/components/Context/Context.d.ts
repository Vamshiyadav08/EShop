import React, { Dispatch, ReactNode, SetStateAction } from 'react';
export interface CartItem {
    count: number;
    productItemId: number;
    productId: number;
    productItemImage: string;
    productItemName: string;
    qtyInStock: number;
    rating: number;
    price: number;
}
export declare type CartItems = CartItem[];
export interface CartItemsContextType {
    cartItems: CartItems;
    setCartItems: Dispatch<SetStateAction<CartItems>>;
}
export declare const CartItemsContext: React.Context<CartItemsContextType>;
declare type CartItemsProviderProps = {
    children: ReactNode;
};
export default function CartItemsProvider({ children }: CartItemsProviderProps): JSX.Element;
export {};
//# sourceMappingURL=Context.d.ts.map