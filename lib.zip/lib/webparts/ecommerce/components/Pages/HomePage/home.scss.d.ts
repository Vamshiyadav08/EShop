declare const styles: {};
export default styles;
//# sourceMappingURL=home.scss.d.ts.map