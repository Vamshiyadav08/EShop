import * as React from 'react';
declare const Home: React.FC<{}>;
export default Home;
//# sourceMappingURL=Home.d.ts.map