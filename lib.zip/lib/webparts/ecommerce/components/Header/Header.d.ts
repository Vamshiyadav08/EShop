import React from "react";
declare const Header: React.FC;
export default Header;
//# sourceMappingURL=Header.d.ts.map