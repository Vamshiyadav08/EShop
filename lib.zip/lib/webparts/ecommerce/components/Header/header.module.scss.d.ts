declare const styles: {
    header: string;
    navHeader: string;
    navLogo: string;
    search: string;
    searchbar: string;
    input: string;
    searchResults: string;
    navActions: string;
    navActionItems: string;
    count: string;
};
export default styles;
//# sourceMappingURL=header.module.scss.d.ts.map