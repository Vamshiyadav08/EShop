declare const styles: {
    headerNav: string;
    headerNavItems: string;
};
export default styles;
//# sourceMappingURL=headerNav.module.scss.d.ts.map