/// <reference types="react" />
export default function HeaderNav(): JSX.Element;
//# sourceMappingURL=HeaderNav.d.ts.map