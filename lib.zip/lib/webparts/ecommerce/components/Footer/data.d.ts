export declare const AboutData: string[];
export declare const Information: string[];
//# sourceMappingURL=data.d.ts.map