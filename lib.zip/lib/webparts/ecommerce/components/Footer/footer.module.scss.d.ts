declare const styles: {
    footer: string;
    footerBrand: string;
    footerItem: string;
};
export default styles;
//# sourceMappingURL=footer.module.scss.d.ts.map