/// <reference types="react" />
export default function Footer(): JSX.Element;
//# sourceMappingURL=Footer.d.ts.map