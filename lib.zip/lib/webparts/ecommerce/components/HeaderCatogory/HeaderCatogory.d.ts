/// <reference types="react" />
export default function HeaderCatogory(): JSX.Element;
//# sourceMappingURL=HeaderCatogory.d.ts.map