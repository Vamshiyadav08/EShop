declare const styles: {
    navCatagories: string;
    catagoryItems: string;
    catagoryImg: string;
    catagoryText: string;
};
export default styles;
//# sourceMappingURL=header.module.scss.d.ts.map