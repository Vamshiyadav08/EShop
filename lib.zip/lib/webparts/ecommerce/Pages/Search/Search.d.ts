/// <reference types="react" />
export default function Search(): JSX.Element;
//# sourceMappingURL=Search.d.ts.map