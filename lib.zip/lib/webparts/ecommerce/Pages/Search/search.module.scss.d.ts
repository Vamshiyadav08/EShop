declare const styles: {};
export default styles;
//# sourceMappingURL=search.module.scss.d.ts.map