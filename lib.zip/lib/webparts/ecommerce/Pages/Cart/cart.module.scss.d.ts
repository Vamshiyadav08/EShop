declare const styles: {
    addItemstoCartImg: string;
    cartContainer: string;
    cart: string;
    cartHeader: string;
    cartItemsContainer: string;
    cartItems: string;
    itemDetails: string;
    operators: string;
    iconsOperators: string;
    countOperator: string;
    priceDetails: string;
    priceHeader: string;
    price: string;
    priceTotal: string;
    priceSaveTag: string;
    link: string;
};
export default styles;
//# sourceMappingURL=cart.module.scss.d.ts.map