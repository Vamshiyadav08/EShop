/// <reference types="react" />
export default function Cart({}: any): JSX.Element;
//# sourceMappingURL=Cart.d.ts.map