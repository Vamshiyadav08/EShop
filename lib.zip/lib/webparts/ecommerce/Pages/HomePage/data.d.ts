export declare const bannerData: {
    imgSrc: any;
}[];
interface TechItem {
    imgSrc: string;
    name: string;
    discount: string;
}
export declare const tech: TechItem[];
export declare const categories: {
    imageSrc: any;
    altText: string;
    categoryName: string;
}[];
export {};
//# sourceMappingURL=data.d.ts.map