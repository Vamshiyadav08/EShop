/// <reference types="react" />
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
export default function Banner(): JSX.Element;
//# sourceMappingURL=Banner.d.ts.map