declare const styles: {
    home: string;
    banner: string;
    slider: string;
    bannerImg: string;
    sectionSale: string;
    countDown: string;
    dealsStrongText: string;
    dealsLightText: string;
    groupTime: string;
    group: string;
    catagoryItemSection: string;
    catagoryItems: string;
    catagoryItemImg: string;
    Items: string;
    discountBadge: string;
    electronicGroupItems: string;
    electronicBgCard: string;
    button: string;
    groupItems: string;
    groupEachItem: string;
    groupItemImg: string;
    enquiry: string;
    enquiryInfo: string;
    enquiryForm: string;
};
export default styles;
//# sourceMappingURL=home.module.scss.d.ts.map