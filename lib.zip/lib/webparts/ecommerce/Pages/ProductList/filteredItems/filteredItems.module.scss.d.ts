declare const styles: {
    filterContainer: string;
    noDataWrapper: string;
    img: string;
    clearListWrapper: string;
    listWrapper: string;
    listItemWrapper: string;
    listImg: string;
    itemDetails: string;
    productItemName: string;
    starIcon: string;
    priceWrapper: string;
    price: string;
};
export default styles;
//# sourceMappingURL=filteredItems.module.scss.d.ts.map