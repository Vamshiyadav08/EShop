/// <reference types="react" />
interface FilteredItemsProps {
    url: string;
}
export default function FilteredItems({ url }: FilteredItemsProps): JSX.Element;
export {};
//# sourceMappingURL=FilteredItems.d.ts.map