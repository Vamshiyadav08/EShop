declare const styles: {
    productList: string;
    sidebar: string;
    menu: string;
    submenu: string;
    menuItem: string;
    catagoryCheckbox: string;
    filterBtn: string;
};
export default styles;
//# sourceMappingURL=productLsit.module.scss.d.ts.map