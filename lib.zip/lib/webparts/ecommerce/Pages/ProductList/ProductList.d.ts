/// <reference types="react" />
export default function ProductList(): JSX.Element;
//# sourceMappingURL=ProductList.d.ts.map