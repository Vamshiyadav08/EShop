export declare const processor: string[];
export declare const secondaryCamera: string[];
export declare const battery: string[];
export declare const color: string[];
export declare const resolution: string[];
export declare const storage: string[];
export declare const primaryCamera: string[];
export declare const screenSize: string[];
export declare const ram: string[];
export declare const minPrice: string[];
export declare const maxPrice: string[];
//# sourceMappingURL=data.d.ts.map