declare const styles: {};
export default styles;
//# sourceMappingURL=orderConfirmed.scss.d.ts.map