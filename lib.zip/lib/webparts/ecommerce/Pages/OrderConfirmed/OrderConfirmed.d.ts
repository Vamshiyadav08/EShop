/// <reference types="react" />
export default function OrderConfirmed(): JSX.Element;
//# sourceMappingURL=OrderConfirmed.d.ts.map