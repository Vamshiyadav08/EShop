declare const styles: {
    OrderConfirmed: string;
    orderpageBtn: string;
    searchBtn: string;
};
export default styles;
//# sourceMappingURL=orderConfirmed.module.scss.d.ts.map