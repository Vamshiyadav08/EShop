declare const styles: {
    buyNow: string;
    loginInfo: string;
    delivaryInfo: string;
    selectedItems: string;
    checkout: string;
    selectedItemsDetails: string;
    img: string;
    details: string;
    productItemName: string;
};
export default styles;
//# sourceMappingURL=buyNow.module.scss.d.ts.map