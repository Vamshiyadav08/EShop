/// <reference types="react" />
export default function BuyNow(): JSX.Element;
//# sourceMappingURL=BuyNow.d.ts.map