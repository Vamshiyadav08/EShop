declare const styles: {};
export default styles;
//# sourceMappingURL=buyNow.scss.d.ts.map