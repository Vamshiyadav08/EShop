declare const styles: {
    login: string;
    loginContainer: string;
    leftWrapper: string;
    flipkartImg: string;
    rightWrapper: string;
    btnContainer: string;
};
export default styles;
//# sourceMappingURL=login.module.scss.d.ts.map