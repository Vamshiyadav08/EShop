declare const styles: {};
export default styles;
//# sourceMappingURL=login.scss.d.ts.map