declare const styles: {};
export default styles;
//# sourceMappingURL=login.module..scss.d.ts.map