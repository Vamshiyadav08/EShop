import React from "react";
declare const Login: React.FC;
export default Login;
//# sourceMappingURL=Login.d.ts.map