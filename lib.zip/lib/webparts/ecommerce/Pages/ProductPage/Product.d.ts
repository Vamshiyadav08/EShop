/// <reference types="react" />
export default function Product(): JSX.Element;
//# sourceMappingURL=Product.d.ts.map