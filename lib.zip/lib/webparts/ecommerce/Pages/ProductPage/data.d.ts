export declare const color: string[];
export declare const ram: string[];
export declare const storage: string[];
//# sourceMappingURL=data.d.ts.map