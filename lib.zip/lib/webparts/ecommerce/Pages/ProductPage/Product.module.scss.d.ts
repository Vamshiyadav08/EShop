declare const styles: {
    productPage: string;
    productContainer: string;
    products: string;
    imageContainer: string;
    imageSideBar: string;
    eachImg: string;
    imageSection: string;
    mainImg: string;
    buttonsContainer: string;
    cartBtn: string;
    buyBtn: string;
    ProductDetails: string;
    ratingContainer: string;
    starIcon: string;
    staticDetails: string;
    price: string;
    highlights: string;
    description: string;
    itemBox: string;
    highlightsList: string;
    descriptionLabel: string;
    descriptionItem: string;
};
export default styles;
//# sourceMappingURL=Product.module.scss.d.ts.map