declare const styles: {
    orders: string;
    img: string;
    status: string;
    icon: string;
};
export default styles;
//# sourceMappingURL=orders.module.scss.d.ts.map