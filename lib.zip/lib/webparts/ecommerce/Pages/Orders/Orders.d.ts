/// <reference types="react" />
export default function Orders(): JSX.Element;
//# sourceMappingURL=Orders.d.ts.map