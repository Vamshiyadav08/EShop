/// <reference types="react" />
export default function NotFound(): JSX.Element;
//# sourceMappingURL=NotFound.d.ts.map