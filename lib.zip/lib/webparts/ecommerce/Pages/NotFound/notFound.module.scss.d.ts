declare const styles: {
    notFound: string;
    imgWrapper: string;
    imgNotFound: string;
};
export default styles;
//# sourceMappingURL=notFound.module.scss.d.ts.map