export declare const bannerData: {
    imgSrc: string;
}[];
//# sourceMappingURL=data.d.ts.map