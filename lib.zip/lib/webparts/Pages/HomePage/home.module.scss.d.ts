declare const styles: {
    home: string;
    banner: string;
    slider: string;
    catagoryItems: string;
    requestSuplierForm: string;
};
export default styles;
//# sourceMappingURL=home.module.scss.d.ts.map