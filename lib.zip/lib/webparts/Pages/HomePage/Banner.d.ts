/// <reference types="react" />
export default function Banner(): JSX.Element;
//# sourceMappingURL=Banner.d.ts.map