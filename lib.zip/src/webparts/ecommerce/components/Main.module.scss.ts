/* tslint:disable */
require("./Main.module.css");
const styles = {
  Main: 'Main_3a9822c9'
};

export default styles;
/* tslint:enable */