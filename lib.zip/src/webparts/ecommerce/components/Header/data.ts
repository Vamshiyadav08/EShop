export const categories = [
    { 
      imageSrc: require('../../assets/catogory/mobiles.jpg'),
      altText: "Mobiles",
      categoryName: "Mobiles"
    },
    { 
      imageSrc: require('../../assets/catogory/appliances.jpg'),
      altText: "Appliances",
      categoryName: "Appliances"
    },
    { 
      imageSrc: require('../../assets/catogory/fashoin.jpg'),
      altText: "Fashoin",
      categoryName: "Fashion"
    },
    { 
      imageSrc: require('../../assets/catogory/Grocery.jpg'),
      altText: "Grocery",
      categoryName: "Grocery"
    },
    { 
      imageSrc: require('../../assets/catogory/toys2.jpg'),
      altText: "Toys",
      categoryName: "Toys"
    },
    { 
      imageSrc: require('../../assets/catogory/travel.jpg'),
      altText: "Travel",
      categoryName: "Travel"
    }
  ];