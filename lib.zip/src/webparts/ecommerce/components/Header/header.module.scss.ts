/* tslint:disable */
require("./header.module.css");
const styles = {
  header: 'header_1d3d5812',
  navHeader: 'navHeader_1d3d5812',
  navLogo: 'navLogo_1d3d5812',
  search: 'search_1d3d5812',
  searchbar: 'searchbar_1d3d5812',
  input: 'input_1d3d5812',
  searchResults: 'searchResults_1d3d5812',
  navActions: 'navActions_1d3d5812',
  navActionItems: 'navActionItems_1d3d5812',
  count: 'count_1d3d5812'
};

export default styles;
/* tslint:enable */