/* tslint:disable */
require("./headerNav.module.css");
const styles = {
  headerNav: 'headerNav_b172bfd6',
  headerNavItems: 'headerNavItems_b172bfd6'
};

export default styles;
/* tslint:enable */