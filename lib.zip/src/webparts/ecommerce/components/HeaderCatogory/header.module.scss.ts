/* tslint:disable */
require("./header.module.css");
const styles = {
  navCatagories: 'navCatagories_241211bd',
  catagoryItems: 'catagoryItems_241211bd',
  catagoryImg: 'catagoryImg_241211bd',
  catagoryText: 'catagoryText_241211bd'
};

export default styles;
/* tslint:enable */