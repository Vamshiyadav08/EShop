/* tslint:disable */
require("./footer.module.css");
const styles = {
  footer: 'footer_0a381f45',
  footerBrand: 'footerBrand_0a381f45',
  footerItem: 'footerItem_0a381f45'
};

export default styles;
/* tslint:enable */