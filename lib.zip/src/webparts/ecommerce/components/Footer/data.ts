export const AboutData =[
    "About Us",
    "Find Store",
    "Catagories",
    "Blogs"
]
export const Information = [
    "Help Center",
    "Money Refund",
    "Shipping",
    "contact Us"
]