/* tslint:disable */
require("./footer.css");
const styles = {

};

export default styles;
/* tslint:enable */