/* tslint:disable */
require("./Main.module.css");
const styles = {
  Main: 'Main_8f5da32e'
};

export default styles;
/* tslint:enable */