/* tslint:disable */
require("./Main.module.css");
const styles = {
  Main: 'Main_2a2fd8c1'
};

export default styles;
/* tslint:enable */