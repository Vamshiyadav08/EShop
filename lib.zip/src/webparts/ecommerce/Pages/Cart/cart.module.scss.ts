/* tslint:disable */
require("./cart.module.css");
const styles = {
  addItemstoCartImg: 'addItemstoCartImg_9519c38a',
  cartContainer: 'cartContainer_9519c38a',
  cart: 'cart_9519c38a',
  cartHeader: 'cartHeader_9519c38a',
  cartItemsContainer: 'cartItemsContainer_9519c38a',
  cartItems: 'cartItems_9519c38a',
  itemDetails: 'itemDetails_9519c38a',
  operators: 'operators_9519c38a',
  iconsOperators: 'iconsOperators_9519c38a',
  countOperator: 'countOperator_9519c38a',
  priceDetails: 'priceDetails_9519c38a',
  priceHeader: 'priceHeader_9519c38a',
  price: 'price_9519c38a',
  priceTotal: 'priceTotal_9519c38a',
  priceSaveTag: 'priceSaveTag_9519c38a',
  link: 'link_9519c38a'
};

export default styles;
/* tslint:enable */