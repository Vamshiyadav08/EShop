/* tslint:disable */
require("./notFound.module.css");
const styles = {
  notFound: 'notFound_a71b49b4',
  imgWrapper: 'imgWrapper_a71b49b4',
  imgNotFound: 'imgNotFound_a71b49b4'
};

export default styles;
/* tslint:enable */