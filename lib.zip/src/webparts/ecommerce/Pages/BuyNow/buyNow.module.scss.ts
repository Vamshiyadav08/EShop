/* tslint:disable */
require("./buyNow.module.css");
const styles = {
  buyNow: 'buyNow_7377ec26',
  loginInfo: 'loginInfo_7377ec26',
  delivaryInfo: 'delivaryInfo_7377ec26',
  selectedItems: 'selectedItems_7377ec26',
  checkout: 'checkout_7377ec26',
  selectedItemsDetails: 'selectedItemsDetails_7377ec26',
  img: 'img_7377ec26',
  details: 'details_7377ec26',
  productItemName: 'productItemName_7377ec26'
};

export default styles;
/* tslint:enable */