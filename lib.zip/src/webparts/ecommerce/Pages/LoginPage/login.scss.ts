/* tslint:disable */
require("./login.css");
const styles = {

};

export default styles;
/* tslint:enable */