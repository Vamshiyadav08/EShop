/* tslint:disable */
require("./login.module..css");
const styles = {

};

export default styles;
/* tslint:enable */