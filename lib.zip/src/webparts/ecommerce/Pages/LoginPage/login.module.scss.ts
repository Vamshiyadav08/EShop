/* tslint:disable */
require("./login.module.css");
const styles = {
  login: 'login_298633e2',
  loginContainer: 'loginContainer_298633e2',
  leftWrapper: 'leftWrapper_298633e2',
  flipkartImg: 'flipkartImg_298633e2',
  rightWrapper: 'rightWrapper_298633e2',
  btnContainer: 'btnContainer_298633e2'
};

export default styles;
/* tslint:enable */