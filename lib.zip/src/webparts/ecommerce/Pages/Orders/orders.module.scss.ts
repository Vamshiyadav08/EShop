/* tslint:disable */
require("./orders.module.css");
const styles = {
  orders: 'orders_34bba420',
  img: 'img_34bba420',
  status: 'status_34bba420',
  icon: 'icon_34bba420'
};

export default styles;
/* tslint:enable */