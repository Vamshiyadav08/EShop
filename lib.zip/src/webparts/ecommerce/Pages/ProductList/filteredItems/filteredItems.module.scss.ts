/* tslint:disable */
require("./filteredItems.module.css");
const styles = {
  filterContainer: 'filterContainer_022f4c6e',
  noDataWrapper: 'noDataWrapper_022f4c6e',
  img: 'img_022f4c6e',
  clearListWrapper: 'clearListWrapper_022f4c6e',
  listWrapper: 'listWrapper_022f4c6e',
  listItemWrapper: 'listItemWrapper_022f4c6e',
  listImg: 'listImg_022f4c6e',
  itemDetails: 'itemDetails_022f4c6e',
  productItemName: 'productItemName_022f4c6e',
  starIcon: 'starIcon_022f4c6e',
  priceWrapper: 'priceWrapper_022f4c6e',
  price: 'price_022f4c6e'
};

export default styles;
/* tslint:enable */