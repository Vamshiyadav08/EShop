/* tslint:disable */
require("./productLsit.module.css");
const styles = {
  productList: 'productList_530939b6',
  sidebar: 'sidebar_530939b6',
  menu: 'menu_530939b6',
  submenu: 'submenu_530939b6',
  menuItem: 'menuItem_530939b6',
  catagoryCheckbox: 'catagoryCheckbox_530939b6',
  filterBtn: 'filterBtn_530939b6'
};

export default styles;
/* tslint:enable */