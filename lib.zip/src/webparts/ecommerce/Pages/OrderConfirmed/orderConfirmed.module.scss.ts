/* tslint:disable */
require("./orderConfirmed.module.css");
const styles = {
  OrderConfirmed: 'OrderConfirmed_72a2a6ce',
  orderpageBtn: 'orderpageBtn_72a2a6ce',
  searchBtn: 'searchBtn_72a2a6ce'
};

export default styles;
/* tslint:enable */