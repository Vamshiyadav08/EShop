/* tslint:disable */
require("./search.module.css");
const styles = {

};

export default styles;
/* tslint:enable */