import React from 'react'
import Header from '../../components/Header/Header'
import HeaderCatogory from '../../components/HeaderCatogory/HeaderCatogory'

export default function Search() {
  return (
    <section>
        <Header/>
        <HeaderCatogory/>
        
    </section>
  )
}
