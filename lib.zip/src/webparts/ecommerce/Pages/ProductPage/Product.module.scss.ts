/* tslint:disable */
require("./Product.module.css");
const styles = {
  productPage: 'productPage_05a28a4e',
  productContainer: 'productContainer_05a28a4e',
  products: 'products_05a28a4e',
  imageContainer: 'imageContainer_05a28a4e',
  imageSideBar: 'imageSideBar_05a28a4e',
  eachImg: 'eachImg_05a28a4e',
  imageSection: 'imageSection_05a28a4e',
  mainImg: 'mainImg_05a28a4e',
  buttonsContainer: 'buttonsContainer_05a28a4e',
  cartBtn: 'cartBtn_05a28a4e',
  buyBtn: 'buyBtn_05a28a4e',
  ProductDetails: 'ProductDetails_05a28a4e',
  ratingContainer: 'ratingContainer_05a28a4e',
  starIcon: 'starIcon_05a28a4e',
  staticDetails: 'staticDetails_05a28a4e',
  price: 'price_05a28a4e',
  highlights: 'highlights_05a28a4e',
  description: 'description_05a28a4e',
  itemBox: 'itemBox_05a28a4e',
  highlightsList: 'highlightsList_05a28a4e',
  descriptionLabel: 'descriptionLabel_05a28a4e',
  descriptionItem: 'descriptionItem_05a28a4e'
};

export default styles;
/* tslint:enable */