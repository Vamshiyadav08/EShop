// interface ProductData {
//     productItemId: string;
//     productId: string;
//     categoryId: string;
//     qtyInStock: number;
//     price: number;
//     numberOfRatings: number;
//     numberOfReviews: number;
//     productItemDescription: string;
//     productItemImage: string;
//     productItemName: string;
//     rating: number;
//     sellers: { sellerId: string; sellerName: string }[];
//     specifications: {
//       Battery: string;
//       Colour: string;
//       Primary_Camera: string;
//       Processor: string;
//       RAM: string;
//       Resolution: string;
//       Screen_Size: string;
//       Secondary_Camera: string;
//       Storage: string;
//     };
//   }
  export const color =[
    "white",
    "black",
    "blue"
  ]
  export const  ram = [
    "6GB",
    "8GB",
    "12GB"
  ]
  export const storage =[
    "64GB",
    "128GB",
    "256GB"
  ]
