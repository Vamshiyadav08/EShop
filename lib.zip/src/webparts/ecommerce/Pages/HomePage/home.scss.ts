/* tslint:disable */
require("./home.css");
const styles = {

};

export default styles;
/* tslint:enable */