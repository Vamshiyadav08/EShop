/* tslint:disable */
require("./home.module.css");
const styles = {
  home: 'home_5ad1fa8b',
  banner: 'banner_5ad1fa8b',
  slider: 'slider_5ad1fa8b',
  bannerImg: 'bannerImg_5ad1fa8b',
  sectionSale: 'sectionSale_5ad1fa8b',
  countDown: 'countDown_5ad1fa8b',
  dealsStrongText: 'dealsStrongText_5ad1fa8b',
  dealsLightText: 'dealsLightText_5ad1fa8b',
  groupTime: 'groupTime_5ad1fa8b',
  group: 'group_5ad1fa8b',
  catagoryItemSection: 'catagoryItemSection_5ad1fa8b',
  catagoryItems: 'catagoryItems_5ad1fa8b',
  catagoryItemImg: 'catagoryItemImg_5ad1fa8b',
  Items: 'Items_5ad1fa8b',
  discountBadge: 'discountBadge_5ad1fa8b',
  electronicGroupItems: 'electronicGroupItems_5ad1fa8b',
  electronicBgCard: 'electronicBgCard_5ad1fa8b',
  button: 'button_5ad1fa8b',
  groupItems: 'groupItems_5ad1fa8b',
  groupEachItem: 'groupEachItem_5ad1fa8b',
  groupItemImg: 'groupItemImg_5ad1fa8b',
  enquiry: 'enquiry_5ad1fa8b',
  enquiryInfo: 'enquiryInfo_5ad1fa8b',
  enquiryForm: 'enquiryForm_5ad1fa8b'
};

export default styles;
/* tslint:enable */